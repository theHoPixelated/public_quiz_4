from tkinter import *

TEXT_FONT = ('Helvetica', 9, 'bold')


def main():
   global travel, health, age, gender
   
   root = Tk()
   root.title('RISK ASSESSMENT')
   w, h = 500, 130
   canvas = Canvas(root, width=w, bg="black",
                            height=h, relief='raised', borderwidth=3)
   canvas.pack(side='top', fill=X)

   canvas.create_line(0, 50, w, 50, fill="white")

   #self.c1 = self.canvas.create_oval(23, 39, 42, 58, fill='light yellow')
   c1 = canvas.create_oval(160, 39, 179, 58, fill='light yellow')
   low_risk = canvas.create_text(37, 50, fill="lawn green",
                                       font="Times 15 italic bold",
                                       text="LOW\n\nRISK")
   high_risk = canvas.create_text(463, 50, fill="red",
                                        font="Times 15 italic bold",
                                        text="HIGH\n\nRISK")

   Label(root, text='Check all boxes that apply', font=TEXT_FONT,).pack()

   def submit_button_pressed():
      value = [
         travel.get(), health.get(), age.get(),
         gender.get()
         ]
      i = 0
      for v in value:
         if v == True:
            move_right()
         i += 1
      sub["state"] = "disabled"
      pop_up_window()
      

   def refresh_button_pressed():
      value = [
         travel.get(), health.get(), age.get(),
         gender.get()
         ]
      var = [travel, health, age, gender]
      i = 0
      for v, var in zip(value, var):
         if v == True:
            var.set(False)
         i += 1
      inital_pos = [180, 39, 199, 58]
      canvas.coords(c1, inital_pos)
      sub["state"] = "normal"
                             

   def move_right():
      current = [round(x) for x in (canvas.coords(c1))]
      current[0] = current[0] + 50
      current[2] = current[2] + 50
      canvas.coords(c1, current)


   def pop_up_window():
      new_window = Toplevel(root)
      x = root.winfo_x()
      y = root.winfo_y()
      new_window.geometry('350x400')
      new_window.geometry("+%d+%d" % (x + 550, y + 10))
      new_window.title('Info')
      new_window.configure(bg='black')        
      scrollbar = Scrollbar(new_window)
      text = 'GROUPS AT HIGHER RISK FOR COVID-19\n\n' \
      'AIR TRAVEL\n\n' \
      'Air travel requires spending time in security lines and ' \
      'airport terminals, which can bring you in close contact with '\
      'other people and frequently touched surfaces. Most viruses and ' \
      'other germs do not spread easily on flights because of how air ' \
      'circulates and is filtered on airplanes. However, social distancing ' \
      'is difficult on crowded flights, and you may have to sit near ' \
      'others (within 6 feet), sometimes for hours. This may increase ' \
      'your risk for exposure to the virus that causes COVID-19.\n\n' \
      'PEOPLE AGED 65 YEARS AND OLDER\n' \
      'Although COVID-19 can affect any group, the older you are, ' \
      'the higher your risk of serious disease. Eight out of 10 deaths ' \
      'reported in the U.S. have been in adults 65 years or older; ' \
      'risk of death is highest among those 85 years or older. ' \
      'The immune systems of older adults weaken with age, making it ' \
      'harder to fight off infections. Also, older adults commonly ' \
      'have chronic diseases that can increase the risk of severe ' \
      'illness from COVID-19.\n\n' \
      'ASTHMA (MODERATE-TO-SEVERE)\n' \
      'COVID-19 can affect your respiratory tract ' \
      '(nose, throat, lungs), cause an asthma attack, and ' \
      'possibly lead to pneumonia and serious illness.\n\n' \
      'CHRONIC KIDNEY DISEASE BEING TREATED ' \
      'WITH DIALYSIS\n' \
      'Dialysis patients are more prone to infection ' \
      'and severe illness because of weakened immune ' \
      'systems; treatments and procedures to manage ' \
      'kidney failure; and coexisting conditions such ' \
      'as diabetes.\n\n' \
      'CHRONIC LUNG DISEASE\n' \
      'Based on data from other viral respiratory ' \
      'infections, COVID-19 might cause flare-ups of ' \
      'chronic lung diseases leading to severe illness.\n\n' \
      'DIABETES\n' \
      'People with diabetes whose blood sugar levels are often higher '\
      'than their target are more likely to have diabetes-related ' \
      'health problems. Those health problems can make it harder to '\
      'overcome COVID-19.\n\n' \
      'HEMOGLOBIN DISORDERS\n' \
      'Living with a hemoglobin disorder can lead to serious ' \
      'multi-organ complications, and underlying medical conditions ' \
      '(such as heart disease, liver disease, diabetes, iron overload, ' \
      'kidney disease, viral infections, or weakened immune system) ' \
      'may increase the risk of severe illness from COVID-19.\n\n' \
      'IMMUNOCOMPROMISED\n' \
      'People with a weakened immune system have reduced ability to ' \
      'fight infectious diseases, including viruses like COVID-19. ' \
      'Knowledge is limited about the virus that causes COVID-19, ' \
      'but based on similar viruses, there is concern that ' \
      'immunocompromised patients may remain infectious for longer ' \
      'than other COVID-19 patients.\n\n' \
      'LIVER DISEASE\n' \
      'Severe illness caused by COVID-19 and the medications used to ' \
      'treat some severe consequences of COVID-19 can cause strain ' \
      'on the liver, particularly for those with underlying ' \
      'liver problems. People living with serious liver disease ' \
      'can have a weakened immune system, leaving the body less ' \
      'able to fight COVID-19.\n\n' \
      'Source: CDC'
      
      output_text = Text(
         new_window, padx=15, pady=15,
         yscrollcommand=scrollbar.set,
         font=TEXT_FONT,
         fg='white', bg='black',
         wrap=(WORD),)
      output_text.pack(side=LEFT, fill=BOTH)      
      scrollbar.pack(side=RIGHT, fill=Y)
      scrollbar.config(command=output_text.yview)
      output_text.insert(END, '\n')
      output_text.insert(END, text)
   
   travel = BooleanVar()
   health = BooleanVar()
   age = BooleanVar()
   gender = BooleanVar()
   
   b1 = Checkbutton(root, font=TEXT_FONT,
                    text=' Air Traveled Recently',
                    variable=travel, state=NORMAL,) 
   b2 = Checkbutton(root, font=TEXT_FONT,
                    text='Pre-existing Health Condition(s)',
                    variable=health, state=NORMAL,)                                
   b3 = Checkbutton(root, font=TEXT_FONT,
                    text='65 Years Old or Older',
                    variable=age, state=NORMAL,)                               
   b4 = Checkbutton(root, font=TEXT_FONT,
                    text='Male',
                    variable=gender, state=NORMAL,)
   sub = Button(root, text='Submit', font=TEXT_FONT,
                width=10, pady=5, bd=4,
                command=submit_button_pressed)
   refresh = Button(root, text='Refresh', font=TEXT_FONT,
                    width=10, pady=5, bd=4,
                    command=refresh_button_pressed)

   b1.pack()
   b2.pack()
   b3.pack()
   b4.pack()
   sub.pack()
   refresh.pack()
   root.mainloop()
         
# unit test
if __name__ == "__main__":
   main()
