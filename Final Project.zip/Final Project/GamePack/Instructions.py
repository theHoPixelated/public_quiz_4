# Project 6
from tkinter import *

# Sets content & parameters for Help button's print statement
def how_to():
    root = Tk()
    root.title("Instructions")
    root.geometry("500x400")
    root.configure(background = 'black')
    frame = Frame(root)
    frame.pack()

    m = Label(root, text=
              "\n\nINSTRUCTIONS:"
              "\n\nTo calculate your chances of becoming "
              "\ninfected with corona virus, simply answer the first set "
              "\nof questions. For your reference, pre-existing "
              "\nconditions include diabetes, asthma, and cancer."
              "\nYou will find your infection predictions, as well "
              "\nas the number of days needed in social distancing "
              "\non the next screen."
              "\n\nFor the game, read through the text and choose what "
              "\n you will do based on the options. In this choose-your-"
              "\nown-adventure, you will decide how the story plays out."
              "\nThis game has multiple endings. Find out what ending you"
              "\nget, and see if you can go back and get a better ending!",
              fg='white', bg = 'black',
              font=('Arial', 13))
    m.pack(side = 'top')
    
    root.mainloop()
