Pandemic Game

by team "Now Is The Time to Panic" 
Kimberly Ho, Katie Nguyen (Khoung), Lindsey Baek, and Hoang Nguyen

________________________________________________________________________
UPDATE: 

State of the Code Base.
The game is now playable, and the buttons all function. As of right now
the text_file.py works and so does the simulation. The only problem is 
we couldn't exactly get the simulation dot to move with the keys, so at 
the very least, you can still click on it to look at the simulation.
The instructions, help button, and risk assessment are informational
windows that can help you traverse throught the game and also get a 
better understanding of the situation we are living in as of 2020.

What is done.
We finally added the text part of the game. The simulation works.
We updated the help button to have a working search bar. 

Who did what.
Hoang worked on the help button and search bar and pitched in with the 
userguide. Katie worked on the simulation and helped with the search bar
as well as edited the userguide. Lindsey added a story with multiple endings
to the text game Kimberly started, and Lindsey also worked on the Userguide.
Kimberly fixed the simulation to make the dots move and created the main page
that has interactive buttons to send you to the different options.
Overall, even though I've stated that each has worked on the specific thing,
it's more accurate to say that this was what they focused on specifically 
and that we all checked and debugged each other's code together.

Conclusion.
I hope you all enjoy the game, we dedicated a lot of energy into making it
as fun as possible, while also being educative. Have fun!

________________________________________________________________________
State of the Code Base.

As of May 1st, our code base has 3 main aspects and 2 in progress. 
The graphics are rendered, though still in progress. The help button
is finished, and just needs to be polished for asthetic purposes.
As for the search bar, it currently renders a select few results, 
and otherwise shows an error message. As a whole the Code Base is 
set. A lot of polishing and connecting the end results together is
needed in order to see the final product.



What is done.

The population representation is rendered, the amount in 100 is
set, the tech support button as well as number support was 
implemented, the projectFile is being fixed at the moment. Until 
then, this is the current update.


What needs to be done.

Once the afore mentioned is fixed, we will add collision in order to 
change the color of the population. This will represent the number
(in 100s) of people spreading the Corona Virus. As an extra frosting 
top, we will add text based descriptions to enhance the story element
of this game.



Who's doing it.

Katie is working on the graphics, Lindsey on the project file,
Hoang on the search bar, and Kimberly on the readme.txt as well as 
managing the folder and turning it in. So far, the project is coming
together quite nicely.

Update.

Lindsey has fixed the code for projectFile.

