from tkinter import *
import random
from GamePack.Game_ import Game_Play

# Challenge 1 responses
c1_print = ["You’re safe from the rona for now,\nbut your friend gets offended,\n"
                "you’ve stirred up unnecessary negativity,\nand lost"
                " out on a future source of support during this time.\n\n(-100 pts)",
                "You’re safe from the rona for now,\nyour friend ends up deciding not to go either,\n"
                "and thanks you for the advice. You share warm fuzzies.\n\n(+100 pts)"]
# Challenge 2 responses
c2_print = ["(+10 pts)\nYou get a dopamine rush from the reckless spending.\nYou now own an exact replica"
             "of the Game of Thrones throne + 8 new succulents.\n\nBut a few weeks later, "
             "supplies run low nationwide\nand you're left eating stale Ramen noodles on your Game of Thrones seat.\n\n"
            "(-20 pts)",
             "You’re well-stocked when supply chains run low,\n eating fresh, balanced meals.\n"
             "Plus, you get to enjoy that sweet peace of mind\n while watching WorldStar videos of people fighting over"
             " TP.\n(+10 pts)\n\n\nBONUS: You’ve unlocked bonus points in the form\nof a self-care package full of "
             "bath bubbles,\nmeditation CDs, and Netflix, Hulu, AND Disney+ subscriptions.\n(+16 pts)",
             "You start growing potatoes in your backyard\nand you get some chickens for eggs/meat.\n"
             "You're fine when supply chains falter, but you’ve started\nwatching conspiracy theories on Youtube "
             "and wearing tinfoil hats.\nThe fear keeps you up at night- you’re starting to lose it.\n\n(-25 pts)"]
# Challenge 3 responses
c3_print = [" You finally wake up, it’s the year 3499901.\nThe pandemic has been over for centuries.\n\n"
            " In your quest for rest, you’ve genetically morphed into an actual Snorlax.\n"
            "You’re a medical marvel. But you don’t care about that.\nYou’re a Snorlax.\nYou go back to sleep.",

            "You still stress and you forgot to mention the day-drinking\nthat goes along with the yoga-watching,\n"
            "but for the most part, you’re coping okay.\nPerfection is impossible, and you get points for effort.\n"
            " Plus, while procrastinating for your online class, you find a primo meme page.\n\n(+15 pts)",

            "You’re kicking ass in productivity (+10 pts),\nbut you’ve alienated all your friends with your"
            " hyper-positivity,\nand the constantly chants about “being your best self”,\n“living your best life”"
            " and “loving the grind.”\n\n(-18 pts)",

            "You now understand what love really is.\nThe hole in your heart has been filled.\n"
            "You’ve given a home to an animal in need and you’re a better, more whole person for"
            " it.\nYou post a video of your pet that ends up going viral,\nyou stick an ad on it and monetize the"
            " hell out of your source of\nunconditional love. Who says you can’t have your cake and eat it?\n\n"
            "(+30 pts)"]
tier1 = ["ENLIGHTENED + HEALTHY\n\nYou’ve stayed safe, avoided the physical perils of this time-\n"
                  "and on top of that, you’ve achieved inner peace.\nPeople who meet you now,"
                  " find themselves bowing\nand saying namaste, without understanding why.", "ENLIGHTENED + INFECTED\n\n"
                  "You’ve lost the game, but won at life.\nCorona may inhabit your body, but your mind is indestructible.\n"
                   "Win or lose means nothing to you now, because you know Nirvana awaits."]
tier2 = ["ADAPTABLE + HEALTHY\n\nYou’re alive and ready to live, live better than you did before.\n"
                  "Plus, come a full-on apocalypse, you’re fairly confident you’ll be alright\n",
                  "ADAPTABLE + INFECTED\n\nSo you didn’t win, but you had a good run.\n"
                  "Bad luck hits us all sometimes, but you’ve already\nproven your fighting spirit.\n"
                  "Mind over body means you’ve lost for now,\nbut you’re not quite defeated just yet."]
tier3 = ["OFF THE DEEP END + HEALTHY\n\nCongrats, you’ve made it to the end- intact, "
                  "but just barely.\nHow you’ve managed to get through daily life\npre-pandemic even,"
                  " we’re not sure. We recommend\ndaily doses of Oprah podcasts and endorphin-pumping\n"
                  " cute animal videos to prepare your mind for Covid-19: Fall 2020.", "OFF THE DEEP END"
                  "+ INFECTED\n\nThis didn’t end well for you, physically or mentally.\n"
                  "We strongly recommend major life reassessment.\nGodspeed."]
health_stat = 'infected' # placeholder
pts = 800   # placeholder


# Introduces game scenario & allows user to opt in/out of game
def Run_Program(Canvas):
    intro = Label(Canvas, text='BREAKING NEWS: CORONA VIRUS OUTBREAK\n\n'
                               'An official state of emergency has been declared.\n'
                               'Covid-19 continues to spread at alarming rates,\n'
                               'leaving disastrous, worldwide impacts in its wake.\n\n'
                               'Starting today, nations have been ordered\n under lockdown'
                               'to help slow the spread and save lives.\n'
                               'You are being called upon to do your part- and stay home!\n\n'
                               'The need for cooperation is urgent,\n'
                               '--but the choice remains yours.\n\n'
                               'THE QUARANTINE BEGINS.',
                  bd=1, relief="solid", bg='black', fg='white',
                  font="Times 15 bold", width=700, height=300, anchor=CENTER)
    intro.place(relx=.5, rely=.5, anchor="center")

    gridFrame = Frame(Canvas, bg='black')

    a = Button(gridFrame, text="Screw it. Fake news.\n You leave the house, go party.",
                   command=lambda: intro_end(Canvas, gridFrame),
                   width=27, height=3)
    a.grid(row=0, column=0, pady=10, padx=25, sticky=W)

    b = Button(gridFrame, text="You choose to listen.\nYou stay home.",
                  command=lambda: intro_start(Canvas, gridFrame),
                  width=27, height=3)
    b.grid(row=0, column=1, pady=10, padx=25, sticky=W)

    gridFrame.pack(side=BOTTOM)

# User opts out of game, redirects to homepage
def intro_end(Canvas, gridFrame):
    gridFrame.destroy()
    end_game = Label(Canvas, text="GAME END\nYou are infected.\n"
                                  "A shame, because you missed the whole game!\n\n"
                                  "Exit to return to the homepage,\nwhere you can check out our Virus Simulation,\n"
                                  "calculate your chances of Covid-19 infection via the Risk Assessment,\n or "
                                  "start the game over!",
                     bd=1, relief="solid", bg='black', fg='white',
                     font="Times 15", width=700, height=300, anchor=CENTER)
    end_game.place(relx=.5, rely=.5, anchor="center")

    gridFrame = Frame(Canvas, bg='black')

# User opts in, explains game instructions
def intro_start(Canvas, gridFrame):
    gridFrame.destroy()
    game_detail = Label(Canvas, text="Let's get this quarantine started!\n"
                                     "Think of this game as self-isolation survival.\n\n"

                                     "You will be presented with challenges and choices.\n"
                                     "The choices you make will either win/lose you Mental Health Points (MHPs).\n\n"

                                     "The game ends when:\n (a) you leave the house (essential activities excluded)\n"
                                     " or (b) you become infected.\n\nEveryone leaves the house eventually,"
                                     " but WHEN and HOW you leave\nchanges your chances of becoming infected.\n\n"

                                     "While your health status (infected/healthy) determines whether "
                                     "you win or lose,\nyour total MHPs determines whether you emerge from "
                                     "quarantine\nas Enlightened (Tier 1), Adaptable (Tier 2), or "
                                     "Off the Deep End (Tier 3)!\n\n"

                                     "So make good choices! Remember, your goal is to balance your mental health\n"
                                     "with your physical health, as the pandemic continues and the stakes rise.\n\n"

                                     "Note: For detailed descriptions of Tiers, search \'Tier Status\' in our FAQ\n"
                                     "(found via the homepage HELP button). You may visit our FAQ\nat any point "
                                     "during the game for any other questions or instructions.",
                        bd=1, relief="solid",
                        bg='black', fg='white', font="Times 13", width=700, height=600, anchor=CENTER)
    game_detail.place(relx=.5, rely=.5, anchor="center")

    gridFrame = Frame(Canvas, bg='black')

    start_game = Button(gridFrame, text="START",
                        command=lambda: stage_1(Canvas, gridFrame),
                        width=25, height=2)
    start_game.grid(row=0, column=1, pady=10, padx=25, sticky=W)

    gridFrame.pack(side=BOTTOM)

# Presents user with 1st challenge/choices
def stage_1(Canvas, gridFrame):
    gridFrame.destroy()
    challenge_1 = Label(Canvas, text="WELCOME TO.. THE SAFE HOUSE.\n"
                                     "(AKA YOUR SAFE HOUSE)\n(AKA IT'S JUST YOUR HOUSE)\n\n\n"
                                     "Day 1 of Quarantine.\n\'DING!\' Your friend just texted you.\n"
                                     "\"Yooo, it's a gorgeous day! Let's hit the beach!!\n"
                                     "Lockdown shmockdown- it's just 1 day!\""
                                     "\n\nYou text back...",
                     bd=1, relief="solid", bg='black', fg='white',
                     font="Times 14", width=800, height=600, anchor=CENTER)
    challenge_1.place(relx=.5, rely=.5, anchor="center")

    gridFrame = Frame(Canvas, bg='black')

    a = Button(gridFrame, text="Let's do it!!",
               command=lambda: gameOver(Canvas, gridFrame),
               width=30, height=5)
    a.grid(row=0, column=0, pady=10, padx=25, sticky=W)

    b = Button(gridFrame,text="No, screw you!!",
               command=lambda: c1_b(Canvas, gridFrame),
               width=30, height=5)
    b.grid(row=0, column=1, pady=10, padx=25, sticky=W)

    c = Button(gridFrame, text="No thanks,\nbetter safe than sorry for now!\n"
                               "All love, but you should probably\n"
                               "rethink this one too!",
                                command=lambda: c1_c(Canvas, gridFrame),
                                width=30, height=5)
    c.grid(row=0, column=3, pady=10, padx=25, sticky=W)

    gridFrame.pack(side=BOTTOM)

# Prints response to opt b, challenge 1
def c1_b(Canvas, gridFrame):
    gridFrame.destroy()
    c1 = Label(Canvas, text=c1_print[0],
                bd=1, relief="solid", bg='black', fg='white',
                font="Impact 15", width=700, height=300, anchor=CENTER)
    c1.place(relx=.5, rely=.5, anchor="center")

    gridFrame = Frame(Canvas, bg='black')
    next_b = Button(gridFrame, text="NEXT CHALLENGE",
                    command=lambda: stage_2(Canvas, gridFrame),
                    width=25, height=2)
    next_b.grid(row=0, column=1, pady=10, padx=25, sticky=W)
    gridFrame.pack(side=BOTTOM)

# Prints response to opt c, challenge 1
def c1_c(Canvas, gridFrame):
    gridFrame.destroy()
    c1 = Label(Canvas, text=c1_print[1],
                   bd=1, relief="solid", bg='black', fg='white',
                   font="Impact 15", width=700, height=300, anchor=CENTER)
    c1.place(relx=.5, rely=.5, anchor="center")
    gridFrame = Frame(Canvas, bg='black')
    next_b = Button(gridFrame, text="NEXT CHALLENGE",
                    command=lambda: stage_2(Canvas, gridFrame),
                    width=25, height=2)
    next_b.grid(row=0, column=1, pady=10, padx=25, sticky=W)
    gridFrame.pack(side=BOTTOM)

# Presents user with 2nd challenge/choices
def stage_2(Canvas, gridFrame):
    gridFrame.destroy()
    challenge_2 = Label(Canvas, text="EDD/STIMULUS CASH COMES IN!!",
                     bd=1, relief="solid", bg='black', fg='white',
                     font="Times 12", width=800, height=600, anchor=CENTER)
    challenge_2.place(relx=.5, rely=.5, anchor="center")

    gridFrame = Frame(Canvas, bg='black')

    a = Button(gridFrame, text="Go on an online shopping spree",
               command=lambda: c2_a(Canvas, gridFrame),
               width=30, height=5)
    a.grid(row=0, column=0, pady=10, padx=25, sticky=W)

    b = Button(gridFrame, text="Use the money\nto stock up on supplies",
               command=lambda: c2_b(Canvas, gridFrame),
               width=30, height=5)
    b.grid(row=0, column=1, pady=10, padx=25, sticky=W)

    c = Button(gridFrame, text="Hoard it,\nbury it in the walls of your house."
                               "\nTrust no one.The end is coming.",
                                command=lambda: c2_c(Canvas, gridFrame),
                                width=30, height=5)
    c.grid(row=0, column=3, pady=10, padx=25, sticky=W)

    gridFrame.pack(side=BOTTOM)

# Prints response to opt a, challenge 2
def c2_a(Canvas, gridFrame):
    gridFrame.destroy()
    c2 = Label(Canvas, text=c2_print[0],
                   bd=1, relief="solid", bg='black', fg='white',
                   font="Impact 15", width=700, height=300, anchor=CENTER)
    c2.place(relx=.5, rely=.5, anchor="center")
    gridFrame = Frame(Canvas, bg='black')

    next = Button(gridFrame, text="NEXT CHALLENGE",
                  command=lambda: stage_3(Canvas, gridFrame),
                  width=25, height=2)
    next.grid(row=0, column=1, pady=10, padx=25, sticky=W)

    gridFrame.pack(side=BOTTOM)

# Prints response to opt b, challenge 2
def c2_b(Canvas, gridFrame):
    gridFrame.destroy()

    c2 = Label(Canvas, text=c2_print[1],
                   bd=1, relief="solid", bg='black', fg='white',
                   font="Impact 15", width=700, height=300, anchor=CENTER)
    c2.place(relx=.5, rely=.5, anchor="center")
    gridFrame = Frame(Canvas, bg='black')

    next = Button(gridFrame, text="NEXT CHALLENGE",
                  command=lambda: stage_3(Canvas, gridFrame),
                  width=25, height=2)
    next.grid(row=0, column=1, pady=10, padx=25, sticky=W)

    gridFrame.pack(side=BOTTOM)

# Prints response to opt c, challenge 2
def c2_c(Canvas, gridFrame):
    gridFrame.destroy()

    c2 = Label(Canvas, text=c2_print[2],
                   bd=1, relief="solid", bg='black', fg='white',
                   font="Impact 15", width=700, height=300, anchor=CENTER)
    c2.place(relx=.5, rely=.5, anchor="center")

    gridFrame = Frame(Canvas, bg='black')

    next = Button(gridFrame, text="NEXT CHALLENGE",
                  command=lambda: stage_3(Canvas, gridFrame),
                  width=25, height=2)
    next.grid(row=0, column=1, pady=10, padx=25, sticky=W)

    gridFrame.pack(side=BOTTOM)

# Presents user with 3rd challenge/choices
def stage_3(Canvas, gridFrame):
    gridFrame.destroy()
    challenge_3 = Label(Canvas, text="BOREDOM ENSUES.\n\nYou’ve now watched every watchable show on Netflix.\n"
                                     " You’ve even resorted to Adam Sandler movies.\n"
                                     " The days and weeks stretch ahead of you, looking dangerously"
                                     " monotonous and empty.\nYou stop showering. You stop brushing your teeth,"
                                     " your hair.\nIt’s grossing you out.\nOkay, time to come up with a plan,"
                                     " a strategy.",
                        bd=1, relief="solid", bg='black', fg='white', font="Times 12", width=400, height=200,
                        anchor=CENTER)
    challenge_3.place(relx=.5, rely=.5, anchor="center")

    gridFrame = Frame(Canvas, bg='black')

    a = Button(gridFrame, text="PLAN A:\nHm? What? Oh, plan? I don’t know.\n"
                               "What’s the point? What time is it?\nGoing to sleep. "
                               "Rest. Lots of rest.\nThat’s my plan.", command=lambda: c3_a(Canvas, gridFrame),
               width=40, height=6)
    a.grid(row=0, column=0, pady=10, padx=25, sticky=W)

    b = Button(gridFrame, text="PLAN B:\nYou start following this yoga Youtuber.\n"
                               "You're not doign yoga, just watching her dog that\nstretches with her, but "
                               "you do lay on a yoga mat\nwhile you watch.", command=lambda: c3_b(Canvas, gridFrame),
               width=40, height=6)
    b.grid(row=1, column=0, pady=10, padx=25, sticky=W)

    c = Button(gridFrame, text="PLAN C:\n5-8 am: meditate, pilates. 8-10 am:"
                               " clean,\nmeal prep, home improvement projects,\nperfect your banana bread recipe, "
                               "and learn\nabout stocks. 10:10 am, the real work begins.",
               command=lambda: c3_c(Canvas, gridFrame), width=40, height=6)
    c.grid(row=1, column=3, pady=10, padx=25, sticky=W)

    d = Button(gridFrame, text="PLAN D:\nYou adopt/foster a pet.", command=lambda: c3_d(Canvas, gridFrame),
               width=40, height=6)
    d.grid(row=0, column=3, pady=10, padx=25, sticky=W)

    gridFrame.pack(side=BOTTOM)

# Prints response to opt a, challenge 3
def c3_a(Canvas, gridFrame):
    gridFrame.destroy()

    c3 = Label(Canvas, text=c3_print[0],
               bd=1, relief="solid", bg='black', fg='white',
               font="Impact 15", width=700, height=300, anchor=CENTER)
    c3.place(relx=.5, rely=.5, anchor="center")

    gridFrame = Frame(Canvas, bg='black')

    done = Button(gridFrame, text="Game Over",
                  command=lambda: gameOver(Canvas, gridFrame),
                  width=25, height=2)
    done.grid(row=0, column=1, pady=10, padx=25, sticky=W)

    gridFrame.pack(side=BOTTOM)

# Prints response to opt b, challenge 3
def c3_b(Canvas, gridFrame):
    gridFrame.destroy()
    c3 = Label(Canvas, text=c3_print[1],
               bd=1, relief="solid", bg='black', fg='white',
               font="Impact 15", width=700, height=300, anchor=CENTER)
    c3.place(relx=.5, rely=.5, anchor="center")
    gridFrame = Frame(Canvas, bg='black')

    next = Button(gridFrame, text="NEXT CHALLENGE",
                  command=lambda: gameOver(Canvas, gridFrame),
                  width=25, height=2)
    next.grid(row=0, column=1, pady=10, padx=25, sticky=W)

    gridFrame.pack(side=BOTTOM)

# Prints response to opt c, challenge 3
def c3_c(Canvas, gridFrame):
    gridFrame.destroy()
    c3 = Label(Canvas, text=c3_print[2],
               bd=1, relief="solid", bg='black', fg='white',
               font="Impact 15", width=700, height=300, anchor=CENTER)
    c3.place(relx=.5, rely=.5, anchor="center")
    gridFrame = Frame(Canvas, bg='black')

    next = Button(gridFrame, text="NEXT CHALLENGE",
                  command=lambda: gameOver(Canvas, gridFrame),
                  width=25, height=2)
    next.grid(row=0, column=1, pady=10, padx=25, sticky=W)

    gridFrame.pack(side=BOTTOM)

# Prints response to opt d, challenge 3
def c3_d(Canvas, gridFrame):
    gridFrame.destroy()
    c3 = Label(Canvas, text=c3_print[3],
               bd=1, relief="solid", bg='black', fg='white',
               font="Impact 15", width=700, height=300, anchor=CENTER)
    c3.place(relx=.5, rely=.5, anchor="center")

    gridFrame = Frame(Canvas, bg='black')

    next = Button(gridFrame, text="NEXT CHALLENGE",
                  command=lambda: gameOver(Canvas, gridFrame),
                  width=25, height=2)
    next.grid(row=0, column=1, pady=10, padx=25, sticky=W)

    gridFrame.pack(side=BOTTOM)

# End of game, presents user with their tier/results
def gameOver(Canvas, gridFrame):
    gridFrame.destroy()

    total_pts = 'Your Total Pts: ' + str(pts)
    total_print = Label(Canvas, text=total_pts, bd=1, relief="solid", bg='black',
                        fg='white',
                        font="Times 12", width=200, height=200, anchor=CENTER)
    total_print.place(relx=.3, rely=.3, anchor="center")

    gridFrame = Frame(Canvas, bg='black')
    if 700 < pts < 1001:
        t1 = Button(Canvas, text='Congrats, Tier 1!\nClick here.',
                       command=lambda: show_t1(Canvas, gridFrame),
                       width=30, height=5)
        t1.place(relx=.5, rely=.5, anchor="center")
    elif 300 < pts <700:
        t2 = Button(Canvas, text='Solid, Tier 2!\nClick here.',
                    command=lambda: show_t2(Canvas, gridFrame),
                    width=30, height=5)
        t2.place(relx=.5, rely=.5, anchor="center")
    elif pts < 300:
        t3 = Button(gridFrame, text='Better luck next time, Tier 3\nClick here.',
                    command=lambda: show_t3(Canvas, gridFrame),
                    width=30, height=5)
        t3.place(relx=.5, rely=.5, anchor="center")

# Tier 1 print
def show_t1(Canvas, gridFrame):
    gridFrame.destroy()

    if health_stat == 'healthy':
        t1_win = Label(Canvas, text=tier1[0], bd=1, relief="solid", bg='black',
                       fg='white',
                       font="Impact 16", width=400, height=600, anchor=CENTER)
        t1_win.place(relx=.5, rely=.5, anchor="center")
    else:
        t1_lose = Label(Canvas, text=tier1[1], bd=1, relief="solid", bg='black',
                       fg='white',
                       font="Impact 16", width=400, height=600, anchor=CENTER)
        t1_lose.place(relx=.5, rely=.5, anchor="center")

# Tier 2 print
def show_t2(Canvas, gridFrame):
    gridFrame.destroy()

    if health_stat == 'healthy':
        t2_win = Label(Canvas, text=tier2[0], bd=1, relief="solid", bg='black',
                       fg='white',
                       font="Impact 16", width=400, height=600, anchor=CENTER)
    else:
        t2_lose = Label(Canvas, text=tier2[1], bd=1, relief="solid", bg='black',
                        fg='white',
                        font="Impact 16", width=400, height=600, anchor=CENTER)

# Tier 3 print
def show_t3(Canvas, gridFrame):
    gridFrame.destroy()

    if health_stat == 'healthy':
        t3_win = Label(Canvas, text=tier3[0], bd=1, relief="solid", bg='black',
                       fg='white',
                       font="Impact 16", width=400, height=600, anchor=CENTER)
    else:
        t3_lose = Label(Canvas, text=tier3[1], bd=1, relief="solid", bg='black',
                        fg='white',
                        font="Impact 16", width=400, height=600, anchor=CENTER)

# Main
def launch_game():
    Window = Tk()
    Window.title('COVID-19')
    Window.geometry('800x600')
    Window.configure(background='black')
    Run_Program(Window)

    Window.mainloop()